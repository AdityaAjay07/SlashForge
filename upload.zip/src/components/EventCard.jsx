function EventCard() {
  return (
    <div className="event-card">
      <img
        className="event-image"
        src="https://images.unsplash.com/photo-1540575467063-178a50c2df87"
        alt="Event"
      />

      <div className="event-details">
        <h3>Tech Summit 2026</h3>

        <p>📅 September 15, 2026</p>

        <p>📍 College of Engineering Trivandrum</p>
      </div>
    </div>
  )
}

export default EventCard