import './App.css'
import Navbar from './components/Navbar'
import Hero from './components/Hero'
import EventCard from './components/EventCard'

function App() {
  return (
    <div>
      <Navbar />
      <Hero />
      <EventCard />
    </div>
  )
}

export default App